/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Production;

import java.util.Date;

/**
 *
 * @author luisp
 */
public class ProductReview {

    private int ProductReviewID;
    private int ProductID;
    private String ReviewerName;
    private Date ReviewDate;
    private String EmailAdress;
    private int rating;
    private String Comments;
    private Date ModifiedDate;

    public int getProductReviewID() {
        return ProductReviewID;
    }

    public void setProductReviewID(int ProductReviewID) {
        this.ProductReviewID = ProductReviewID;
    }

    public int getProductID() {
        return ProductID;
    }

    public void setProductID(int ProductID) {
        this.ProductID = ProductID;
    }

    public String getReviewerName() {
        return ReviewerName;
    }

    public void setReviewerName(String ReviewerName) {
        this.ReviewerName = ReviewerName;
    }

    public Date getReviewDate() {
        return ReviewDate;
    }

    public void setReviewDate(Date ReviewDate) {
        this.ReviewDate = ReviewDate;
    }

    public String getEmailAdress() {
        return EmailAdress;
    }

    public void setEmailAdress(String EmailAdress) {
        this.EmailAdress = EmailAdress;
    }

    public int getRating() {
        return rating;
    }

    public void setRating(int rating) {
        this.rating = rating;
    }

    public String getComments() {
        return Comments;
    }

    public void setComments(String Comments) {
        this.Comments = Comments;
    }

    public Date getModifiedDate() {
        return ModifiedDate;
    }

    public void setModifiedDate(Date ModifiedDate) {
        this.ModifiedDate = ModifiedDate;
    }

}
