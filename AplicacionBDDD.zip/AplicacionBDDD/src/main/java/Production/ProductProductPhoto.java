/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Production;

import java.util.Date;

/**
 *
 * @author luisp
 */
public class ProductProductPhoto {

    private int ProductID;
    private int ProductPhotoID;
    private boolean Primary;
    private Date ModifiedDate;

    public int getProductID() {
        return ProductID;
    }

    public void setProductID(int ProductID) {
        this.ProductID = ProductID;
    }

    public int getProductPhotoID() {
        return ProductPhotoID;
    }

    public void setProductPhotoID(int ProductPhotoID) {
        this.ProductPhotoID = ProductPhotoID;
    }

    public boolean isPrimary() {
        return Primary;
    }

    public void setPrimary(boolean Primary) {
        this.Primary = Primary;
    }

    public Date getModifiedDate() {
        return ModifiedDate;
    }

    public void setModifiedDate(Date ModifiedDate) {
        this.ModifiedDate = ModifiedDate;
    }

}
