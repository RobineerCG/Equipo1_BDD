/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Production;

import java.util.Date;

/**
 *
 * @author luisp
 */
public class Illustration {

    private int IllustrationID;
    private String Diagram;
    private Date ModifiedDate;

    public int getIllustrationID() {
        return IllustrationID;
    }

    public void setIllustrationID(int IllustrationID) {
        this.IllustrationID = IllustrationID;
    }

    public String getDiagram() {
        return Diagram;
    }

    public void setDiagram(String Diagram) {
        this.Diagram = Diagram;
    }

    public Date getModifiedDate() {
        return ModifiedDate;
    }

    public void setModifiedDate(Date ModifiedDate) {
        this.ModifiedDate = ModifiedDate;
    }

}
