/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Production;

import java.math.BigDecimal;
import java.util.Date;

/**
 *
 * @author luisp
 */
public class Product {

    private int ProductID;
    private String Name;
    private String ProductNumber;
    private boolean MakeFlag;
    private boolean FinishedGoodsFlag;
    private String Color;
    private int SafetyStockLevel;
    private int reorderpoint;
    private BigDecimal StandardCost;
    private BigDecimal ListPrice;
    private String Size;
    private String SizeUnitMeasureCode;
    private String WeightUnitMeasureCode;
    private double Weight;
    private int DaysToManufacture;
    private String ProductLine;
    private String Class;
    private String Style;
    private int ProductSubCategory;
    private int ProductModelID;
    private Date SellStartDate;
    private Date SellEndDate;
    private Date DiscountinuedDate;
    private String rowguid;
    private Date ModifiedDate;

    public int getProductID() {
        return ProductID;
    }

    public void setProductID(int ProductID) {
        this.ProductID = ProductID;
    }

    public String getName() {
        return Name;
    }

    public void setName(String Name) {
        this.Name = Name;
    }

    public String getProductNumber() {
        return ProductNumber;
    }

    public void setProductNumber(String ProductNumber) {
        this.ProductNumber = ProductNumber;
    }

    public boolean isMakeFlag() {
        return MakeFlag;
    }

    public void setMakeFlag(boolean MakeFlag) {
        this.MakeFlag = MakeFlag;
    }

    public boolean isFinishedGoodsFlag() {
        return FinishedGoodsFlag;
    }

    public void setFinishedGoodsFlag(boolean FinishedGoodsFlag) {
        this.FinishedGoodsFlag = FinishedGoodsFlag;
    }

    public String getColor() {
        return Color;
    }

    public void setColor(String Color) {
        this.Color = Color;
    }

    public int getSafetyStockLevel() {
        return SafetyStockLevel;
    }

    public void setSafetyStockLevel(int SafetyStockLevel) {
        this.SafetyStockLevel = SafetyStockLevel;
    }

    public int getReorderpoint() {
        return reorderpoint;
    }

    public void setReorderpoint(int reorderpoint) {
        this.reorderpoint = reorderpoint;
    }

    public BigDecimal getStandardCost() {
        return StandardCost;
    }

    public void setStandardCost(BigDecimal StandardCost) {
        this.StandardCost = StandardCost;
    }

    public BigDecimal getListPrice() {
        return ListPrice;
    }

    public void setListPrice(BigDecimal ListPrice) {
        this.ListPrice = ListPrice;
    }

    public String getSize() {
        return Size;
    }

    public void setSize(String Size) {
        this.Size = Size;
    }

    public String getSizeUnitMeasureCode() {
        return SizeUnitMeasureCode;
    }

    public void setSizeUnitMeasureCode(String SizeUnitMeasureCode) {
        this.SizeUnitMeasureCode = SizeUnitMeasureCode;
    }

    public String getWeightUnitMeasureCode() {
        return WeightUnitMeasureCode;
    }

    public void setWeightUnitMeasureCode(String WeightUnitMeasureCode) {
        this.WeightUnitMeasureCode = WeightUnitMeasureCode;
    }

    public double getWeight() {
        return Weight;
    }

    public void setWeight(double Weight) {
        this.Weight = Weight;
    }

    public int getDaysToManufacture() {
        return DaysToManufacture;
    }

    public void setDaysToManufacture(int DaysToManufacture) {
        this.DaysToManufacture = DaysToManufacture;
    }

    public String getProductLine() {
        return ProductLine;
    }

    public void setProductLine(String ProductLine) {
        this.ProductLine = ProductLine;
    }

    public String getClas() {
        return Class;
    }

    public void setClass(String Class) {
        this.Class = Class;
    }

    public String getStyle() {
        return Style;
    }

    public void setStyle(String Style) {
        this.Style = Style;
    }

    public int getProductSubCategory() {
        return ProductSubCategory;
    }

    public void setProductSubCategory(int ProductSubCategory) {
        this.ProductSubCategory = ProductSubCategory;
    }

    public int getProductModelID() {
        return ProductModelID;
    }

    public void setProductModelID(int ProductModelID) {
        this.ProductModelID = ProductModelID;
    }

    public Date getSellStartDate() {
        return SellStartDate;
    }

    public void setSellStartDate(Date SellStartDate) {
        this.SellStartDate = SellStartDate;
    }

    public Date getSellEndDate() {
        return SellEndDate;
    }

    public void setSellEndDate(Date SellEndDate) {
        this.SellEndDate = SellEndDate;
    }

    public Date getDiscountinuedDate() {
        return DiscountinuedDate;
    }

    public void setDiscountinuedDate(Date DiscountinuedDate) {
        this.DiscountinuedDate = DiscountinuedDate;
    }

    public String getRowguid() {
        return rowguid;
    }

    public void setRowguid(String rowguid) {
        this.rowguid = rowguid;
    }

    public Date getModifiedDate() {
        return ModifiedDate;
    }

    public void setModifiedDate(Date ModifiedDate) {
        this.ModifiedDate = ModifiedDate;
    }

}
