/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Production;

import java.util.Date;

/**
 *
 * @author luisp
 */
public class ProductInventory {

    private int ProductID;
    private int LocationID;
    private String Shelf;
    private int Bin;
    private int Quantity;
    private String rowguid;
    private Date ModifiedDate;

    public int getProductID() {
        return ProductID;
    }

    public void setProductID(int ProductID) {
        this.ProductID = ProductID;
    }

    public int getLocationID() {
        return LocationID;
    }

    public void setLocationID(int LocationID) {
        this.LocationID = LocationID;
    }

    public String getShelf() {
        return Shelf;
    }

    public void setShelf(String Shelf) {
        this.Shelf = Shelf;
    }

    public int getBin() {
        return Bin;
    }

    public void setBin(int Bin) {
        this.Bin = Bin;
    }

    public int getQuantity() {
        return Quantity;
    }

    public void setQuantity(int Quantity) {
        this.Quantity = Quantity;
    }

    public String getRowguid() {
        return rowguid;
    }

    public void setRowguid(String rowguid) {
        this.rowguid = rowguid;
    }

    public Date getModifiedDate() {
        return ModifiedDate;
    }

    public void setModifiedDate(Date ModifiedDate) {
        this.ModifiedDate = ModifiedDate;
    }

}
