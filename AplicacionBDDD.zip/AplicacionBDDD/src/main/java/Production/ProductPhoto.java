/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Production;

import java.util.Date;

/**
 *
 * @author luisp
 */
public class ProductPhoto {

    private int ProductPhotoID;
    private String ThumbNailPhoto;
    private String ThumbNailPhotoFileName;
    private String LargePhoto;
    private String LargePhotoFileName;
    private Date ModifiedDate;

    public int getProductPhotoID() {
        return ProductPhotoID;
    }

    public void setProductPhotoID(int ProductPhotoID) {
        this.ProductPhotoID = ProductPhotoID;
    }

    public String getThumbNailPhoto() {
        return ThumbNailPhoto;
    }

    public void setThumbNailPhoto(String ThumbNailPhoto) {
        this.ThumbNailPhoto = ThumbNailPhoto;
    }

    public String getThumbNailPhotoFileName() {
        return ThumbNailPhotoFileName;
    }

    public void setThumbNailPhotoFileName(String ThumbNailPhotoFileName) {
        this.ThumbNailPhotoFileName = ThumbNailPhotoFileName;
    }

    public String getLargePhoto() {
        return LargePhoto;
    }

    public void setLargePhoto(String LargePhoto) {
        this.LargePhoto = LargePhoto;
    }

    public String getLargePhotoFileName() {
        return LargePhotoFileName;
    }

    public void setLargePhotoFileName(String LargePhotoFileName) {
        this.LargePhotoFileName = LargePhotoFileName;
    }

    public Date getModifiedDate() {
        return ModifiedDate;
    }

    public void setModifiedDate(Date ModifiedDate) {
        this.ModifiedDate = ModifiedDate;
    }

}
