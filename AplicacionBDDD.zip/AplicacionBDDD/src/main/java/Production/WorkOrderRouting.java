/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Production;

import java.math.BigDecimal;
import java.util.Date;

/**
 *
 * @author luisp
 */
public class WorkOrderRouting {

    private int WorkOrderID;
    private int ProductID;
    private int OperationSequence;
    private int LocationID;
    private Date ScheduledStartDate;
    private Date ScheduledEndDate;
    private Date ActualStartDate;
    private Date ActualEndDate;
    private double ActualResourceHrs;
    private BigDecimal PlannedCost;
    private BigDecimal ActualCost;
    private Date ModifiedDate;

    public int getWorkOrderID() {
        return WorkOrderID;
    }

    public void setWorkOrderID(int WorkOrderID) {
        this.WorkOrderID = WorkOrderID;
    }

    public int getProductID() {
        return ProductID;
    }

    public void setProductID(int ProductID) {
        this.ProductID = ProductID;
    }

    public int getOperationSequence() {
        return OperationSequence;
    }

    public void setOperationSequence(int OperationSequence) {
        this.OperationSequence = OperationSequence;
    }

    public int getLocationID() {
        return LocationID;
    }

    public void setLocationID(int LocationID) {
        this.LocationID = LocationID;
    }

    public Date getScheduledStartDate() {
        return ScheduledStartDate;
    }

    public void setScheduledStartDate(Date ScheduledStartDate) {
        this.ScheduledStartDate = ScheduledStartDate;
    }

    public Date getScheduledEndDate() {
        return ScheduledEndDate;
    }

    public void setScheduledEndDate(Date ScheduledEndDate) {
        this.ScheduledEndDate = ScheduledEndDate;
    }

    public Date getActualStartDate() {
        return ActualStartDate;
    }

    public void setActualStartDate(Date ActualStartDate) {
        this.ActualStartDate = ActualStartDate;
    }

    public Date getActualEndDate() {
        return ActualEndDate;
    }

    public void setActualEndDate(Date ActualEndDate) {
        this.ActualEndDate = ActualEndDate;
    }

    public double getActualResourceHrs() {
        return ActualResourceHrs;
    }

    public void setActualResourceHrs(double ActualResourceHrs) {
        this.ActualResourceHrs = ActualResourceHrs;
    }

    public BigDecimal getPlannedCost() {
        return PlannedCost;
    }

    public void setPlannedCost(BigDecimal PlannedCost) {
        this.PlannedCost = PlannedCost;
    }

    public BigDecimal getActualCost() {
        return ActualCost;
    }

    public void setActualCost(BigDecimal ActualCost) {
        this.ActualCost = ActualCost;
    }

    public Date getModifiedDate() {
        return ModifiedDate;
    }

    public void setModifiedDate(Date ModifiedDate) {
        this.ModifiedDate = ModifiedDate;
    }

}
