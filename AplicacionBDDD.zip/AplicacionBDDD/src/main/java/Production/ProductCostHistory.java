/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Production;

import java.math.BigDecimal;
import java.util.Date;

/**
 *
 * @author luisp
 */
public class ProductCostHistory {

    private int ProductID;
    private Date StartDate;
    private Date EndDate;
    private BigDecimal StandardCost;
    private Date ModifiedDate;

    public int getProductID() {
        return ProductID;
    }

    public void setProductID(int ProductID) {
        this.ProductID = ProductID;
    }

    public Date getStartDate() {
        return StartDate;
    }

    public void setStartDate(Date StartDate) {
        this.StartDate = StartDate;
    }

    public Date getEndDate() {
        return EndDate;
    }

    public void setEndDate(Date EndDate) {
        this.EndDate = EndDate;
    }

    public BigDecimal getStandardCost() {
        return StandardCost;
    }

    public void setStandardCost(BigDecimal StandardCost) {
        this.StandardCost = StandardCost;
    }

    public Date getModifiedDate() {
        return ModifiedDate;
    }

    public void setModifiedDate(Date ModifiedDate) {
        this.ModifiedDate = ModifiedDate;
    }
    
    
}
