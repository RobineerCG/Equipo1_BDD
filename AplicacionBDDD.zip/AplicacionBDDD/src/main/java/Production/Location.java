/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Production;

import java.math.BigDecimal;
import java.util.Date;

/**
 *
 * @author luisp
 */
public class Location {

    private int LocationID;
    private String Name;
    private BigDecimal CostRate;
    private double Availability;
    private Date ModifiedDate;

    public int getLocationID() {
        return LocationID;
    }

    public void setLocationID(int LocationID) {
        this.LocationID = LocationID;
    }

    public String getName() {
        return Name;
    }

    public void setName(String Name) {
        this.Name = Name;
    }

    public BigDecimal getCostRate() {
        return CostRate;
    }

    public void setCostRate(BigDecimal CostRate) {
        this.CostRate = CostRate;
    }

    public double getAvailability() {
        return Availability;
    }

    public void setAvailability(double Availability) {
        this.Availability = Availability;
    }

    public Date getModifiedDate() {
        return ModifiedDate;
    }

    public void setModifiedDate(Date ModifiedDate) {
        this.ModifiedDate = ModifiedDate;
    }

}
