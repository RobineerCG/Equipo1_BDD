/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Production;

import java.math.BigDecimal;
import java.util.Date;

/**
 *
 * @author luisp
 */
public class TransactionHistory {

    private int TransactionID;
    private int ProductID;
    private int ReferenceOrderID;
    private int ReferenceOrderLineID;
    private Date TransactionDate;
    private char TransactionType;
    private int Quantity;
    private BigDecimal ActualCost;
    private Date ModifiedDate;

    public int getTransactionID() {
        return TransactionID;
    }

    public void setTransactionID(int TransactionID) {
        this.TransactionID = TransactionID;
    }

    public int getProductID() {
        return ProductID;
    }

    public void setProductID(int ProductID) {
        this.ProductID = ProductID;
    }

    public int getReferenceOrderID() {
        return ReferenceOrderID;
    }

    public void setReferenceOrderID(int ReferenceOrderID) {
        this.ReferenceOrderID = ReferenceOrderID;
    }

    public int getReferenceOrderLineID() {
        return ReferenceOrderLineID;
    }

    public void setReferenceOrderLineID(int ReferenceOrderLineID) {
        this.ReferenceOrderLineID = ReferenceOrderLineID;
    }

    public Date getTransactionDate() {
        return TransactionDate;
    }

    public void setTransactionDate(Date TransactionDate) {
        this.TransactionDate = TransactionDate;
    }

    public char getTransactionType() {
        return TransactionType;
    }

    public void setTransactionType(char TransactionType) {
        this.TransactionType = TransactionType;
    }

    public int getQuantity() {
        return Quantity;
    }

    public void setQuantity(int Quantity) {
        this.Quantity = Quantity;
    }

    public BigDecimal getActualCost() {
        return ActualCost;
    }

    public void setActualCost(BigDecimal ActualCost) {
        this.ActualCost = ActualCost;
    }

    public Date getModifiedDate() {
        return ModifiedDate;
    }

    public void setModifiedDate(Date ModifiedDate) {
        this.ModifiedDate = ModifiedDate;
    }

}
