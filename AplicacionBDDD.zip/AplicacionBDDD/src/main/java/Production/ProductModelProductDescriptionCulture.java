/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Production;

import java.util.Date;

/**
 *
 * @author luisp
 */
public class ProductModelProductDescriptionCulture {

    private int ProductModelID;
    private int ProductDescriptionID;
    private String CultureID;
    private Date ModifiedDate;

    public int getProductModelID() {
        return ProductModelID;
    }

    public void setProductModelID(int ProductModelID) {
        this.ProductModelID = ProductModelID;
    }

    public int getProductDescriptionID() {
        return ProductDescriptionID;
    }

    public void setProductDescriptionID(int ProductDescriptionID) {
        this.ProductDescriptionID = ProductDescriptionID;
    }

    public String getCultureID() {
        return CultureID;
    }

    public void setCultureID(String CultureID) {
        this.CultureID = CultureID;
    }

    public Date getModifiedDate() {
        return ModifiedDate;
    }

    public void setModifiedDate(Date ModifiedDate) {
        this.ModifiedDate = ModifiedDate;
    }

}
