/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Production;

import java.util.Date;

/**
 *
 * @author luisp
 */
public class BillofMaterials {

    private int BillOfMaterialsID;
    private int ProductAssembly;
    private int ComponentID;
    private Date StartDate;
    private Date EndDate;
    private String UnitMeasureCode;
    private int BOMLevel;
    private double PerAssemblyQty;
    private Date ModifiedDate;

    public int getBillOfMaterialsID() {
        return BillOfMaterialsID;
    }

    public void setBillOfMaterialsID(int BillOfMaterialsID) {
        this.BillOfMaterialsID = BillOfMaterialsID;
    }

    public int getProductAssembly() {
        return ProductAssembly;
    }

    public void setProductAssembly(int ProductAssembly) {
        this.ProductAssembly = ProductAssembly;
    }

    public int getComponentID() {
        return ComponentID;
    }

    public void setComponentID(int ComponentID) {
        this.ComponentID = ComponentID;
    }

    public Date getStartDate() {
        return StartDate;
    }

    public void setStartDate(Date StartDate) {
        this.StartDate = StartDate;
    }

    public Date getEndDate() {
        return EndDate;
    }

    public void setEndDate(Date EndDate) {
        this.EndDate = EndDate;
    }

    public String getUnitMeasureCode() {
        return UnitMeasureCode;
    }

    public void setUnitMeasureCode(String UnitMeasureCode) {
        this.UnitMeasureCode = UnitMeasureCode;
    }

    public int getBOMLevel() {
        return BOMLevel;
    }

    public void setBOMLevel(int BOMLevel) {
        this.BOMLevel = BOMLevel;
    }

    public double getPerAssemblyQty() {
        return PerAssemblyQty;
    }

    public void setPerAssemblyQty(double PerAssemblyQty) {
        this.PerAssemblyQty = PerAssemblyQty;
    }

    public Date getModifiedDate() {
        return ModifiedDate;
    }

    public void setModifiedDate(Date ModifiedDate) {
        this.ModifiedDate = ModifiedDate;
    }

}
