/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Production;

import java.util.Date;

/**
 *
 * @author luisp
 */
public class ProductDescription {

    private int ProductDescriptionID;
    private String Description;
    private String rowguid;
    private Date ModifiedDate;

    public int getProductDescriptionID() {
        return ProductDescriptionID;
    }

    public void setProductDescriptionID(int ProductDescriptionID) {
        this.ProductDescriptionID = ProductDescriptionID;
    }

    public String getDescription() {
        return Description;
    }

    public void setDescription(String Description) {
        this.Description = Description;
    }

    public String getRowguid() {
        return rowguid;
    }

    public void setRowguid(String rowguid) {
        this.rowguid = rowguid;
    }

    public Date getModifiedDate() {
        return ModifiedDate;
    }

    public void setModifiedDate(Date ModifiedDate) {
        this.ModifiedDate = ModifiedDate;
    }

}
