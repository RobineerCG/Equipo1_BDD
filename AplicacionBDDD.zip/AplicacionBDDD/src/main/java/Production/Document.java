/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Production;

import java.util.Date;

/**
 *
 * @author luisp
 */
public class Document {

    private String DocumentNode;
    private int DocumentLevel;
    private String Title;
    private int Owner;
    private boolean FolderFlag;
    private String FileName;
    private String FileExtension;
    private String Revision;
    private int ChangeNumber;
    private int Status;
    private String DocumentSummary;
    private String Document;
    private String rowguid;
    private Date ModifiedDate;

    public String getDocumentNode() {
        return DocumentNode;
    }

    public void setDocumentNode(String DocumentNode) {
        this.DocumentNode = DocumentNode;
    }

    public int getDocumentLevel() {
        return DocumentLevel;
    }

    public void setDocumentLevel(int DocumentLevel) {
        this.DocumentLevel = DocumentLevel;
    }

    public String getTitle() {
        return Title;
    }

    public void setTitle(String Title) {
        this.Title = Title;
    }

    public int getOwner() {
        return Owner;
    }

    public void setOwner(int Owner) {
        this.Owner = Owner;
    }

    public boolean isFolderFlag() {
        return FolderFlag;
    }

    public void setFolderFlag(boolean FolderFlag) {
        this.FolderFlag = FolderFlag;
    }

    public String getFileName() {
        return FileName;
    }

    public void setFileName(String FileName) {
        this.FileName = FileName;
    }

    public String getFileExtension() {
        return FileExtension;
    }

    public void setFileExtension(String FileExtension) {
        this.FileExtension = FileExtension;
    }

    public String getRevision() {
        return Revision;
    }

    public void setRevision(String Revision) {
        this.Revision = Revision;
    }

    public int getChangeNumber() {
        return ChangeNumber;
    }

    public void setChangeNumber(int ChangeNumber) {
        this.ChangeNumber = ChangeNumber;
    }

    public int getStatus() {
        return Status;
    }

    public void setStatus(int Status) {
        this.Status = Status;
    }

    public String getDocumentSummary() {
        return DocumentSummary;
    }

    public void setDocumentSummary(String DocumentSummary) {
        this.DocumentSummary = DocumentSummary;
    }

    public String getDocument() {
        return Document;
    }

    public void setDocument(String Document) {
        this.Document = Document;
    }

    public String getRowguid() {
        return rowguid;
    }

    public void setRowguid(String rowguid) {
        this.rowguid = rowguid;
    }

    public Date getModifiedDate() {
        return ModifiedDate;
    }

    public void setModifiedDate(Date ModifiedDate) {
        this.ModifiedDate = ModifiedDate;
    }

}
