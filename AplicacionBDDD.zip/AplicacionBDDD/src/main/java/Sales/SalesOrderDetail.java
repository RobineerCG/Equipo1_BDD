/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Sales;

import java.math.BigDecimal;
import java.util.Date;

/**
 *
 * @author luisp
 */
public class SalesOrderDetail {

    private int SalesOrderID;
    private int SalesOrderDetailID;
    private String CarrierTrackingNumber;
    private int OrderQty;
    private int ProductID;
    private int SpecialOfferID;
    private double UnitPrice;
    private double UnitPriceDiscount;
    private double LineTotal;
    private String rowguid;
    private String ModifiedDate;

    public int getSalesOrderID() {
        return SalesOrderID;
    }

    public void setSalesOrderID(int SalesOrderID) {
        this.SalesOrderID = SalesOrderID;
    }

    public int getSalesOrderDetailID() {
        return SalesOrderDetailID;
    }

    public void setSalesOrderDetailID(int SalesOrderDetailID) {
        this.SalesOrderDetailID = SalesOrderDetailID;
    }

    public String getCarrierTrackingNumber() {
        return CarrierTrackingNumber;
    }

    public void setCarrierTrackingNumber(String CarrierTrackingNumber) {
        this.CarrierTrackingNumber = CarrierTrackingNumber;
    }

    public int getOrderQty() {
        return OrderQty;
    }

    public void setOrderQty(int OrderQty) {
        this.OrderQty = OrderQty;
    }

    public int getProductID() {
        return ProductID;
    }

    public void setProductID(int ProductID) {
        this.ProductID = ProductID;
    }

    public int getSpecialOfferID() {
        return SpecialOfferID;
    }

    public void setSpecialOfferID(int SpecialOfferID) {
        this.SpecialOfferID = SpecialOfferID;
    }

    public double getUnitPrice() {
        return UnitPrice;
    }

    public void setUnitPrice(double UnitPrice) {
        this.UnitPrice = UnitPrice;
    }

    public double getUnitPriceDiscount() {
        return UnitPriceDiscount;
    }

    public void setUnitPriceDiscount(double UnitPriceDiscount) {
        this.UnitPriceDiscount = UnitPriceDiscount;
    }

    public double getLineTotal() {
        return LineTotal;
    }

    public void setLineTotal(double LineTotal) {
        this.LineTotal = LineTotal;
    }

    public String getRowguid() {
        return rowguid;
    }

    public void setRowguid(String rowguid) {
        this.rowguid = rowguid;
    }

    public String getModifiedDate() {
        return ModifiedDate;
    }

    public void setModifiedDate(String ModifiedDate) {
        this.ModifiedDate = ModifiedDate;
    }

}
