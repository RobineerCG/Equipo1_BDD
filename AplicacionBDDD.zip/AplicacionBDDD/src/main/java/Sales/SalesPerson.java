/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Sales;

import java.math.BigDecimal;
import java.util.Date;

/**
 *
 * @author luisp
 */
public class SalesPerson {

    private int BusinessEntityID;
    private int TerritoryID;
    private BigDecimal SalesQuota;
    private BigDecimal Bonus;
    private BigDecimal CommissionPct;
    private BigDecimal SalesYTD;
    private BigDecimal SalesLastYear;
    private String rowguid;
    private Date ModifiedDate;

    public int getBusinessEntityID() {
        return BusinessEntityID;
    }

    public void setBusinessEntityID(int BusinessEntityID) {
        this.BusinessEntityID = BusinessEntityID;
    }

    public int getTerritoryID() {
        return TerritoryID;
    }

    public void setTerritoryID(int TerritoryID) {
        this.TerritoryID = TerritoryID;
    }

    public BigDecimal getSalesQuota() {
        return SalesQuota;
    }

    public void setSalesQuota(BigDecimal SalesQuota) {
        this.SalesQuota = SalesQuota;
    }

    public BigDecimal getBonus() {
        return Bonus;
    }

    public void setBonus(BigDecimal Bonus) {
        this.Bonus = Bonus;
    }

    public BigDecimal getCommissionPct() {
        return CommissionPct;
    }

    public void setCommissionPct(BigDecimal CommissionPct) {
        this.CommissionPct = CommissionPct;
    }

    public BigDecimal getSalesYTD() {
        return SalesYTD;
    }

    public void setSalesYTD(BigDecimal SalesYTD) {
        this.SalesYTD = SalesYTD;
    }

    public BigDecimal getSalesLastYear() {
        return SalesLastYear;
    }

    public void setSalesLastYear(BigDecimal SalesLastYear) {
        this.SalesLastYear = SalesLastYear;
    }

    public String getRowguid() {
        return rowguid;
    }

    public void setRowguid(String rowguid) {
        this.rowguid = rowguid;
    }

    public Date getModifiedDate() {
        return ModifiedDate;
    }

    public void setModifiedDate(Date ModifiedDate) {
        this.ModifiedDate = ModifiedDate;
    }

}
