/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Sales;

import java.math.BigDecimal;

/**
 *
 * @author luisp
 */
public class SalesTerritory {

    private int TerritoryID;
    private String Name;
    private String CountryRegionCode;
    private String Group;
    private BigDecimal SalesYTD;
    private BigDecimal SalesLastYear;
    private BigDecimal CostYTD;
    private BigDecimal CostLastYear;
    private String rowguid;

    public int getTerritoryID() {
        return TerritoryID;
    }

    public void setTerritoryID(int TerritoryID) {
        this.TerritoryID = TerritoryID;
    }

    public String getName() {
        return Name;
    }

    public void setName(String Name) {
        this.Name = Name;
    }

    public String getCountryRegionCode() {
        return CountryRegionCode;
    }

    public void setCountryRegionCode(String CountryRegionCode) {
        this.CountryRegionCode = CountryRegionCode;
    }

    public String getGroup() {
        return Group;
    }

    public void setGroup(String Group) {
        this.Group = Group;
    }

    public BigDecimal getSalesYTD() {
        return SalesYTD;
    }

    public void setSalesYTD(BigDecimal SalesYTD) {
        this.SalesYTD = SalesYTD;
    }

    public BigDecimal getSalesLastYear() {
        return SalesLastYear;
    }

    public void setSalesLastYear(BigDecimal SalesLastYear) {
        this.SalesLastYear = SalesLastYear;
    }

    public BigDecimal getCostYTD() {
        return CostYTD;
    }

    public void setCostYTD(BigDecimal CostYTD) {
        this.CostYTD = CostYTD;
    }

    public BigDecimal getCostLastYear() {
        return CostLastYear;
    }

    public void setCostLastYear(BigDecimal CostLastYear) {
        this.CostLastYear = CostLastYear;
    }

    public String getRowguid() {
        return rowguid;
    }

    public void setRowguid(String rowguid) {
        this.rowguid = rowguid;
    }

}
