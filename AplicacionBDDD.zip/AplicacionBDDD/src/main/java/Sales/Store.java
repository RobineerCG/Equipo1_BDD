/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Sales;

import java.util.Date;

/**
 *
 * @author luisp
 */
public class Store {

    private int BusinessEntityID;
    private String Name;
    private int SalesPersonID;
    private String Demographics;
    private String rowguid;
    private Date ModifiedDate;

    public int getBusinessEntityID() {
        return BusinessEntityID;
    }

    public void setBusinessEntityID(int BusinessEntityID) {
        this.BusinessEntityID = BusinessEntityID;
    }

    public String getName() {
        return Name;
    }

    public void setName(String Name) {
        this.Name = Name;
    }

    public int getSalesPersonID() {
        return SalesPersonID;
    }

    public void setSalesPersonID(int SalesPersonID) {
        this.SalesPersonID = SalesPersonID;
    }

    public String getDemographics() {
        return Demographics;
    }

    public void setDemographics(String Demographics) {
        this.Demographics = Demographics;
    }

    public String getRowguid() {
        return rowguid;
    }

    public void setRowguid(String rowguid) {
        this.rowguid = rowguid;
    }

    public Date getModifiedDate() {
        return ModifiedDate;
    }

    public void setModifiedDate(Date ModifiedDate) {
        this.ModifiedDate = ModifiedDate;
    }

}
