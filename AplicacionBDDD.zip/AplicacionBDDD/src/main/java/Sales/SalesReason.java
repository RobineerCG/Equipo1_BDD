/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Sales;

import java.util.Date;

/**
 *
 * @author luisp
 */
public class SalesReason {

    private int SalesReasonID;
    private String Name;
    private String ReasonType;
    private Date ModifiedDate;

    public int getSalesReasonID() {
        return SalesReasonID;
    }

    public void setSalesReasonID(int SalesReasonID) {
        this.SalesReasonID = SalesReasonID;
    }

    public String getName() {
        return Name;
    }

    public void setName(String Name) {
        this.Name = Name;
    }

    public String getReasonType() {
        return ReasonType;
    }

    public void setReasonType(String ReasonType) {
        this.ReasonType = ReasonType;
    }

    public Date getModifiedDate() {
        return ModifiedDate;
    }

    public void setModifiedDate(Date ModifiedDate) {
        this.ModifiedDate = ModifiedDate;
    }

}
