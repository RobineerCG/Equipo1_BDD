package Sales;

/**
 *
 * @author luisp
 */
public class SalesOrderHeader {

    private int SalesOrderID;
    private int RevisionNumber;
    private String OrderDate;
    private String DueDate;
    private String ShipDate;
    private int Status;
    private int OnlineOrderFlag;
    private String SalesOrderNumber;
    private String PurchaseOrderNumber;
    private String AccountNumber;
    private int CustomerID;
    private int SalesPersonID;
    private int TerritoryID;
    private int BillToAdressID;
    private int ShipToAdressID;
    private int ShipMethodID;
    private int CreditCardID;
    private String CreditCardApprovalCode;
    private int CurrencyRateID;
    private Double SubTotal;
    private Double TaxAmt;
    private Double Freight;
    private Double TotalDue;
    private String Comment;
    private String rowguid;
    private String ModifiedDate;

    public int getSalesOrderID() {
        return SalesOrderID;
    }

    public void setSalesOrderID(int SalesOrderID) {
        this.SalesOrderID = SalesOrderID;
    }

    public int getRevisionNumber() {
        return RevisionNumber;
    }

    public void setRevisionNumber(int RevisionNumber) {
        this.RevisionNumber = RevisionNumber;
    }

    public String getOrderDate() {
        return OrderDate;
    }

    public void setOrderDate(String OrderDate) {
        this.OrderDate = OrderDate;
    }

    public String getDueDate() {
        return DueDate;
    }

    public void setDueDate(String DueDate) {
        this.DueDate = DueDate;
    }

    public String getShipDate() {
        return ShipDate;
    }

    public void setShipDate(String ShipDate) {
        this.ShipDate = ShipDate;
    }

    public String getModifiedDate() {
        return ModifiedDate;
    }

    public void setModifiedDate(String ModifiedDate) {
        this.ModifiedDate = ModifiedDate;
    }

    public int getStatus() {
        return Status;
    }

    public void setStatus(int Status) {
        this.Status = Status;
    }

    public int getOnlineOrderFlag() {
        return OnlineOrderFlag;
    }

    public void setOnlineOrderFlag(int OnlineOrderFlag) {
        this.OnlineOrderFlag = OnlineOrderFlag;
    }

    public String getSalesOrderNumber() {
        return SalesOrderNumber;
    }

    public void setSalesOrderNumber(String SalesOrderNumber) {
        this.SalesOrderNumber = SalesOrderNumber;
    }

    public String getPurchaseOrderNumber() {
        return PurchaseOrderNumber;
    }

    public void setPurchaseOrderNumber(String PurchaseOrderNumber) {
        this.PurchaseOrderNumber = PurchaseOrderNumber;
    }

    public String getAccountNumber() {
        return AccountNumber;
    }

    public void setAccountNumber(String AccountNumber) {
        this.AccountNumber = AccountNumber;
    }

    public int getCustomerID() {
        return CustomerID;
    }

    public void setCustomerID(int CustomerID) {
        this.CustomerID = CustomerID;
    }

    public int getSalesPersonID() {
        return SalesPersonID;
    }

    public void setSalesPersonID(int SalesPersonID) {
        this.SalesPersonID = SalesPersonID;
    }

    public int getTerritoryID() {
        return TerritoryID;
    }

    public void setTerritoryID(int TerritoryID) {
        this.TerritoryID = TerritoryID;
    }

    public int getBillToAdressID() {
        return BillToAdressID;
    }

    public void setBillToAdressID(int BillToAdressID) {
        this.BillToAdressID = BillToAdressID;
    }

    public int getShipToAdressID() {
        return ShipToAdressID;
    }

    public void setShipToAdressID(int ShipToAdressID) {
        this.ShipToAdressID = ShipToAdressID;
    }

    public int getShipMethodID() {
        return ShipMethodID;
    }

    public void setShipMethodID(int ShipMethodID) {
        this.ShipMethodID = ShipMethodID;
    }

    public int getCreditCardID() {
        return CreditCardID;
    }

    public void setCreditCardID(int CreditCardID) {
        this.CreditCardID = CreditCardID;
    }

    public String getCreditCardApprovalCode() {
        return CreditCardApprovalCode;
    }

    public void setCreditCardApprovalCode(String CreditCardApprovalCode) {
        this.CreditCardApprovalCode = CreditCardApprovalCode;
    }

    public int getCurrencyRateID() {
        return CurrencyRateID;
    }

    public void setCurrencyRateID(int CurrencyRateID) {
        this.CurrencyRateID = CurrencyRateID;
    }

    public Double getSubTotal() {
        return SubTotal;
    }

    public void setSubTotal(Double SubTotal) {
        this.SubTotal = SubTotal;
    }

    public Double getTaxAmt() {
        return TaxAmt;
    }

    public void setTaxAmt(Double TaxAmt) {
        this.TaxAmt = TaxAmt;
    }

    public Double getFreight() {
        return Freight;
    }

    public void setFreight(Double Freight) {
        this.Freight = Freight;
    }

    public Double getTotalDue() {
        return TotalDue;
    }

    public void setTotalDue(Double TotalDue) {
        this.TotalDue = TotalDue;
    }

    public String getComment() {
        return Comment;
    }

    public void setComment(String Comment) {
        this.Comment = Comment;
    }

    public String getRowguid() {
        return rowguid;
    }

    public void setRowguid(String rowguid) {
        this.rowguid = rowguid;
    }

}
