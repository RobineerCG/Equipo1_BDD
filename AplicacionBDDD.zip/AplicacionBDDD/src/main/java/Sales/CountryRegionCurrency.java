/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Sales;

import java.util.Date;

/**
 *
 * @author luisp
 */
public class CountryRegionCurrency {

    private String CountryRegionCode;
    private String CurrencyCode;
    private Date ModifiedDate;

    public String getCountryRegionCode() {
        return CountryRegionCode;
    }

    public void setCountryRegionCode(String CountryRegionCode) {
        this.CountryRegionCode = CountryRegionCode;
    }

    public String getCurrencyCode() {
        return CurrencyCode;
    }

    public void setCurrencyCode(String CurrencyCode) {
        this.CurrencyCode = CurrencyCode;
    }

    public Date getModifiedDate() {
        return ModifiedDate;
    }

    public void setModifiedDate(Date ModifiedDate) {
        this.ModifiedDate = ModifiedDate;
    }

}
