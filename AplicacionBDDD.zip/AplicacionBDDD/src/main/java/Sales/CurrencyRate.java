/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Sales;

import java.math.BigDecimal;
import java.util.Date;

/**
 *
 * @author luisp
 */
public class CurrencyRate {

    private int CurrencyRateID;
    private Date CurrencyRateDate;
    private String FromCurrencyCode;
    private String ToCurrencyCode;
    private BigDecimal AverageRate;
    private BigDecimal EndOfDayRate;
    private Date ModifiedDate;

    public int getCurrencyRateID() {
        return CurrencyRateID;
    }

    public void setCurrencyRateID(int CurrencyRateID) {
        this.CurrencyRateID = CurrencyRateID;
    }

    public Date getCurrencyRateDate() {
        return CurrencyRateDate;
    }

    public void setCurrencyRateDate(Date CurrencyRateDate) {
        this.CurrencyRateDate = CurrencyRateDate;
    }

    public String getFromCurrencyCode() {
        return FromCurrencyCode;
    }

    public void setFromCurrencyCode(String FromCurrencyCode) {
        this.FromCurrencyCode = FromCurrencyCode;
    }

    public String getToCurrencyCode() {
        return ToCurrencyCode;
    }

    public void setToCurrencyCode(String ToCurrencyCode) {
        this.ToCurrencyCode = ToCurrencyCode;
    }

    public BigDecimal getAverageRate() {
        return AverageRate;
    }

    public void setAverageRate(BigDecimal AverageRate) {
        this.AverageRate = AverageRate;
    }

    public BigDecimal getEndOfDayRate() {
        return EndOfDayRate;
    }

    public void setEndOfDayRate(BigDecimal EndOfDayRate) {
        this.EndOfDayRate = EndOfDayRate;
    }

    public Date getModifiedDate() {
        return ModifiedDate;
    }

    public void setModifiedDate(Date ModifiedDate) {
        this.ModifiedDate = ModifiedDate;
    }

}
