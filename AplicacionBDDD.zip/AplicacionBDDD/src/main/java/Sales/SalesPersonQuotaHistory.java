/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Sales;

import java.math.BigDecimal;
import java.util.Date;

/**
 *
 * @author luisp
 */
public class SalesPersonQuotaHistory {

    private int BusinessEntityID;
    private Date QuotaDate;
    private BigDecimal SalesQuota;
    private String rowguid;
    private Date ModifiedDate;

    public int getBusinessEntityID() {
        return BusinessEntityID;
    }

    public void setBusinessEntityID(int BusinessEntityID) {
        this.BusinessEntityID = BusinessEntityID;
    }

    public Date getQuotaDate() {
        return QuotaDate;
    }

    public void setQuotaDate(Date QuotaDate) {
        this.QuotaDate = QuotaDate;
    }

    public BigDecimal getSalesQuota() {
        return SalesQuota;
    }

    public void setSalesQuota(BigDecimal SalesQuota) {
        this.SalesQuota = SalesQuota;
    }

    public String getRowguid() {
        return rowguid;
    }

    public void setRowguid(String rowguid) {
        this.rowguid = rowguid;
    }

    public Date getModifiedDate() {
        return ModifiedDate;
    }

    public void setModifiedDate(Date ModifiedDate) {
        this.ModifiedDate = ModifiedDate;
    }

}
