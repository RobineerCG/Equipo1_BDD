/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Sales;

import java.util.Date;

/**
 *
 * @author luisp
 */
public class CreditCard {

    private int CrediCardID;
    private String CardType;
    private String CardNumber;
    private int ExpMonth;
    private int ExpYear;
    private Date ModifiedDate;

    public int getCrediCardID() {
        return CrediCardID;
    }

    public void setCrediCardID(int CrediCardID) {
        this.CrediCardID = CrediCardID;
    }

    public String getCardType() {
        return CardType;
    }

    public void setCardType(String CardType) {
        this.CardType = CardType;
    }

    public String getCardNumber() {
        return CardNumber;
    }

    public void setCardNumber(String CardNumber) {
        this.CardNumber = CardNumber;
    }

    public int getExpMonth() {
        return ExpMonth;
    }

    public void setExpMonth(int ExpMonth) {
        this.ExpMonth = ExpMonth;
    }

    public int getExpYear() {
        return ExpYear;
    }

    public void setExpYear(int ExpYear) {
        this.ExpYear = ExpYear;
    }

    public Date getModifiedDate() {
        return ModifiedDate;
    }

    public void setModifiedDate(Date ModifiedDate) {
        this.ModifiedDate = ModifiedDate;
    }

}
