/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Sales;

import java.util.Date;

/**
 *
 * @author luisp
 */
public class SalesOrderHeaderSalesReason {

    private int SalesOrderID;
    private int SalesReasonID;
    private Date ModifiedDate;

    public int getSalesOrderID() {
        return SalesOrderID;
    }

    public void setSalesOrderID(int SalesOrderID) {
        this.SalesOrderID = SalesOrderID;
    }

    public int getSalesReasonID() {
        return SalesReasonID;
    }

    public void setSalesReasonID(int SalesReasonID) {
        this.SalesReasonID = SalesReasonID;
    }

    public Date getModifiedDate() {
        return ModifiedDate;
    }

    public void setModifiedDate(Date ModifiedDate) {
        this.ModifiedDate = ModifiedDate;
    }

}
