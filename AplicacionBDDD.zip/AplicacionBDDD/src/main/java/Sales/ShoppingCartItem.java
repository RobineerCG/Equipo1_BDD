/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Sales;

import java.util.Date;

/**
 *
 * @author luisp
 */
public class ShoppingCartItem {

    private int ShoppingCartItem;
    private String ShoppingCartID;
    private int Quantity;
    private int ProductID;
    private Date DateCreated;
    private Date ModifiedDate;

    public int getShoppingCartItem() {
        return ShoppingCartItem;
    }

    public void setShoppingCartItem(int ShoppingCartItem) {
        this.ShoppingCartItem = ShoppingCartItem;
    }

    public String getShoppingCartID() {
        return ShoppingCartID;
    }

    public void setShoppingCartID(String ShoppingCartID) {
        this.ShoppingCartID = ShoppingCartID;
    }

    public int getQuantity() {
        return Quantity;
    }

    public void setQuantity(int Quantity) {
        this.Quantity = Quantity;
    }

    public int getProductID() {
        return ProductID;
    }

    public void setProductID(int ProductID) {
        this.ProductID = ProductID;
    }

    public Date getDateCreated() {
        return DateCreated;
    }

    public void setDateCreated(Date DateCreated) {
        this.DateCreated = DateCreated;
    }

    public Date getModifiedDate() {
        return ModifiedDate;
    }

    public void setModifiedDate(Date ModifiedDate) {
        this.ModifiedDate = ModifiedDate;
    }

}
