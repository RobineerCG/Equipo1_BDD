
package DataSource;
import  java.sql.*; // importa driver para SQL Server

public class sqlserver {
    public static String conexion1URL =
            "jdbc:sqlserver://localhost:1433;" +
                    "instanceName=DESKTOP-IJED4S6\\MSSQL1;"
                    + "database=AdventureWorks2019;"
                    + "user=sa;"
                    + "password=1903;"
                    + "encrypt=true;"
                    + "trustServerCertificate=true;"
                    + "loginTimeout=30;";
    
    public static String conexion2URL
            = "jdbc:sqlserver://localhost:4022;"
            + "instanceName=DESKTOP-IJED4S6\\MSSQL2;"
            + "database=AdventureWorks2019;"
            + "user=sa;"
            + "password=1234;"
            + "encrypt=true;"
            + "trustServerCertificate=true;"
            + "loginTimeout=30;";
    
    /* contraseñas Rob
    1: 8e!$uoiS%LvhAw6@pEQV@Sr8
    2: 45LkJpZ%W^A4U8EHAayWLWQ3
    mysql: bGRgLk&msqAhGfd#%o7bSgQy 
    */
        
    public static ResultSet resultSet = null;
    public static ResultSet rs;
    
    
    public sqlserver()
    {
        // INSTANCIA 1
        try(Connection conexion = DriverManager.getConnection(conexion1URL);
            Statement statement = conexion.createStatement();)
        {
            System.out.println("CONEXION EXITOSA");
            System.out.println("conexion = " + conexion);
            String selectSql = "SELECT top(3)* FROM AdventureWorks2019.Sales.SalesOrderDetail AS A ";
            resultSet = statement.executeQuery(selectSql);

            while (resultSet.next()) {
                System.out.println(resultSet.getString(2) + " " + resultSet.getString(3));
            }
            conexion.close(); // cierra la conexion
            
        } catch (SQLException e) {
            System.out.println("CONEXION FALLIDA");
            e.printStackTrace();
        }
        
        // INSTANCIA 2
         try ( Connection conexion = DriverManager.getConnection(conexion2URL);  Statement statement = conexion.createStatement();) {
            System.out.println("CONEXION EXITOSA");
            System.out.println("conexion = " + conexion);

            String selectSql = "SELECT top(3)* FROM AdventureWorks2019.Sales.Currency AS A ";
            resultSet = statement.executeQuery(selectSql);

            while (resultSet.next()) {
                System.out.println(resultSet.getString(2) + " " + resultSet.getString(3));
            }
            conexion.close(); // cierra la conexion
        } catch (SQLException e) {
            System.out.println("CONEXION FALLIDA");
            e.printStackTrace();
        }   
    }

}
