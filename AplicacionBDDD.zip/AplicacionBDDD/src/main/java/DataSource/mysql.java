/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DataSource;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 *
 * @author luisp
 */
public class mysql {

    public Connection connect() {
        Connection con = null;
        String driver = "com.mysql.cj.jdbc.Driver";
        try {
            Class.forName(driver);
            System.out.println("Driver cargado con éxito");
            try {
                con = DriverManager.getConnection("jdbc:mysql://localhost:3306/adventureworks2019?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatatimeCode=false&serverTimezone=UTC&useSSL=false", "root", "190300");
                if (con != null) {
                    //System.out.println("Conexión realizada con éxito");
                    //System.out.println("con = " + con.toString());
                }
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, "Ha ocurrido un error al intentar conectar con la base de datos, " + e.getMessage());
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Ha ocurrido un error al intentar conectar con el driver, " + e.getMessage());
        }
        return con;
    }

}
