
package DAO;

/**
 *
 * @author Roberto
 */
public interface CRUD {
    
    void insert();
    void select();
    void update();
    void delete();
    
}
