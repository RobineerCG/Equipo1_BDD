/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package SOH_CRUD;

import DataSource.sqlserver;
import GUI.DAO;
import SOD_CRUD.SOD_Create;
import static DataSource.sqlserver.rs;
import DAO.CRUD;
import Sales.SalesOrderHeader;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import javax.security.auth.Subject;
import javax.swing.JOptionPane;

/**
 *
 * @author luisp
 */
public class SOH_Create extends javax.swing.JFrame implements CRUD {

    SalesOrderHeader soh = new SalesOrderHeader();
    SOD_Create sodc = new SOD_Create();
    DAO dao = new DAO();
    

    /**
     * Creates new form SOH_Create
     */
    public SOH_Create() {
        initComponents();
    }

    @Override
    public void insert() {
        //generaID();
        generaSON();
        generaPON();
        generaCCAC();
        String statusaux = (String) jComboBox1.getSelectedItem();
        String OrderFlag = (String) jComboBox2.getSelectedItem();
        SimpleDateFormat dtf = new SimpleDateFormat("yyyy/MM/dd");
        Calendar calendar = Calendar.getInstance();
        Date dateobj = calendar.getTime();
        String faux = dtf.format(dateobj);

        soh.setRevisionNumber(Integer.parseInt(jTextField1.getText()));
        soh.setOrderDate(jTextField2.getText());
        soh.setDueDate(jTextField3.getText());
        soh.setShipDate(jTextField4.getText());

        switch (statusaux) {
            case "In process" ->
                soh.setStatus(1);
            case "Approved" ->
                soh.setStatus(2);
            case "Backordered" ->
                soh.setStatus(3);
            case "Rejected" ->
                soh.setStatus(4);
            case "Shipped" ->
                soh.setStatus(5);
            case "Cancelled" ->
                soh.setStatus(6);
            default ->
                soh.setStatus(1);
        }

        switch (OrderFlag) {
            case "Placed by Sales Person" ->
                soh.setOnlineOrderFlag(0);
            case "Placed Online by Customer" ->
                soh.setOnlineOrderFlag(1);
            default ->
                soh.setOnlineOrderFlag(1);
        }

        soh.setAccountNumber(jTextField12.getText());
        soh.setComment(jTextField13.getText());
        soh.setRowguid("6F9619FF-8B86-D011-B42D-00C04FC964FF");
        soh.setModifiedDate(faux);
        
        String insert= "insert into AdventureWorks2019.Sales.SalesOrderHeader"+
                "(SalesOrderID,RevisionNumber, OrderDate, DueDate, ShipDate, [Status], OnlineOrderFlag,"
                +"SalesOrderNumber,PurchaseOrderNumber,AccountNumber,CustomerID,SalesPersonID, TerritoryID,"
                +"BillToAddressID, ShipToAddressID, ShipMethodID, CreditCardID,CreditCardApprovalCode, CurrencyRateID,"
                +"SubTotal, TaxAmt, Freight,TotalDue, Comment, rowguid, ModifiedDate) values"+
                "("+soh.getSalesOrderID()+","+soh.getRevisionNumber()+",'"+soh.getOrderDate()+"','"+soh.getDueDate()+"','"+soh.getShipDate()+"',"
                +soh.getStatus()+","+soh.getOnlineOrderFlag()+",'"+soh.getSalesOrderNumber()+"','"+soh.getPurchaseOrderNumber()+
                "','"+soh.getAccountNumber()+"',"+soh.getCustomerID()+","+soh.getSalesPersonID()+","+soh.getTerritoryID()+
                ","+soh.getBillToAdressID()+","+soh.getShipToAdressID()+","+soh.getShipMethodID()+","+
                soh.getCreditCardID()+",'"+soh.getCreditCardApprovalCode()+"',"+soh.getCurrencyRateID()+","+soh.getSubTotal()+","+
                soh.getTaxAmt()+","+soh.getFreight()+","+soh.getTotalDue()+",'"+soh.getComment()+"','"+soh.getRowguid()+"','"+soh.getModifiedDate()+"')";
        try (Connection con=DriverManager.getConnection(sqlserver.conexion2URL);Statement s=con.createStatement();){
         s.executeUpdate(insert);
         JOptionPane.showMessageDialog(null, "Registro Correcto");
         this.dispose();
         dao.setVisible(true);
         
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, ""+e);
        }

        System.out.println("SalesOrderID: " + soh.getSalesOrderID());
        System.out.println("Revision Number: " + soh.getRevisionNumber());
        System.out.println("OrderDate: " + soh.getOrderDate());
        System.out.println("DueDate: " + soh.getDueDate());
        System.out.println("sd " + soh.getShipDate());
        System.out.println("s " + soh.getStatus());
        System.out.println("oof " + soh.getOnlineOrderFlag());
        System.out.println("Purchase: " + soh.getPurchaseOrderNumber());
        System.out.println("SalesON: " + soh.getSalesOrderNumber());
        System.out.println("Account: " + soh.getAccountNumber());
        System.out.println("Customer: " + soh.getCustomerID());
        System.out.println("SalesPersonID: " + soh.getSalesPersonID());
        System.out.println("TerritoryID: " + soh.getTerritoryID());
        System.out.println("BillToAdress: " + soh.getBillToAdressID());
        System.out.println("ShipID: " + soh.getShipMethodID());
        System.out.println("CreditCard: " + soh.getCreditCardID());
        System.out.println("CCAC: " + soh.getCreditCardApprovalCode());
        System.out.println("CRID: " + soh.getCurrencyRateID());
        System.out.println("SubT: " + soh.getSubTotal());
        System.out.println("TaxAmt: " + soh.getTaxAmt());
        System.out.println("freight" + soh.getTotalDue());
        System.out.println("Comment " + soh.getComment());
        System.out.println("rowguid: " + soh.getRowguid());
        System.out.println("modifiedDate: " + soh.getModifiedDate());
    }

    @Override
    public void select() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void update() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void delete() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public void generaID() {
        int aux;
        String query = "select MAX(SalesOrderID) from AdventureWorks2019.Sales.SalesOrderHeader;";
        try ( Connection conexion = DriverManager.getConnection(sqlserver.conexion2URL);  Statement s = conexion.createStatement()) {
            rs = s.executeQuery(query);
            while (rs.next()) {
                aux = Integer.parseInt(rs.getString(1)) + 1;
                soh.setSalesOrderID(aux);
                jLabel3.setText("" + aux);
                JOptionPane.showMessageDialog(null, "Tu ID Asignado es " + soh.getSalesOrderID() + "\nEscribelo en la siguiente ventana");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "" + e);
        }
    }

    public void generaSON() {
        int numero = (int) (Math.random() * 99999 - 75123 + 1) + 75123;
        soh.setSalesOrderNumber("SO" + numero);
    }

    public void generaPON() {
        int numero = (int) (Math.random() * 1000000000 - 1 + 1) + 1;
        soh.setPurchaseOrderNumber("PO" + numero);
        jLabel11.setText(soh.getPurchaseOrderNumber());
    }

    public void generaCCAC() {
        int numero = (int) (Math.random() * 1000000 - 1 + 1) + 1;
        int numero2 = (int) (Math.random() * 1000000 - 1 + 1) + 1;
        soh.setCreditCardApprovalCode(numero + "Vi" + numero2);
        jLabel22.setText(soh.getCreditCardApprovalCode());
    }

    public void calculos() {
        String query = "select SUM(LineTotal) as total from AdventureWorks2019.Sales.SalesOrderDetail where SalesOrderID=" + soh.getSalesOrderID();
        try ( Connection conexion = DriverManager.getConnection(sqlserver.conexion2URL);  Statement s = conexion.createStatement();) {
            rs = s.executeQuery(query);
            while (rs.next()) {
                JOptionPane.showMessageDialog(null, "El subtotal es $" + rs.getString(1));
                soh.setSubTotal(Double.parseDouble(rs.getString(1)));
                jLabel25.setText("$" + rs.getString(1));
                soh.setTaxAmt(.1 * soh.getSubTotal());
                jLabel28.setText("" + soh.getTaxAmt());
                soh.setFreight(0.00);
                soh.setTotalDue(soh.getSubTotal() + soh.getTaxAmt() + soh.getFreight());
                JOptionPane.showMessageDialog(null, "El total es de $" + soh.getTotalDue());
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "" + e);
        }
    }

    public void validar1() {
        String query = "select * from (select distinct CustomerID from AdventureWorks2019.Sales.Customer)as a where a.CustomerID=" + jTextField5.getText();
        try ( Connection conexion = DriverManager.getConnection(sqlserver.conexion2URL);  Statement s = conexion.createStatement();) {
            rs = s.executeQuery(query);
            while (rs.next()) {
                JOptionPane.showMessageDialog(null, "El dato " + jTextField5.getText() + " es válido");
                soh.setCustomerID(Integer.parseInt(jTextField5.getText()));
                //generarPD();
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "" + e);
        }
    }

    public void validar2() {
        String query = "select * from (select distinct BusinessEntityID from AdventureWorks2019.Sales.SalesPerson)as a where a.BusinessEntityID=" + jTextField6.getText();
        try ( Connection conexion = DriverManager.getConnection(sqlserver.conexion2URL);  Statement s = conexion.createStatement();) {
            rs = s.executeQuery(query);
            while (rs.next()) {
                JOptionPane.showMessageDialog(null, "El dato " + jTextField6.getText() + " es válido");
                soh.setSalesPersonID(Integer.parseInt(jTextField6.getText()));
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "" + e);
        }
    }

    public void validar3() {
        String query = "select * from (select distinct TerritoryID from AdventureWorks2019.Sales.Salesterritory)as a where a.TerritoryID=" + jTextField7.getText();
        try ( Connection conexion = DriverManager.getConnection(sqlserver.conexion2URL);  Statement s = conexion.createStatement();) {
            rs = s.executeQuery(query);
            while (rs.next()) {
                JOptionPane.showMessageDialog(null, "El dato " + jTextField7.getText() + " es válido");
                soh.setTerritoryID(Integer.parseInt(jTextField7.getText()));
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "" + e);
        }
    }

    public void validar4() {
        String query = "select * from (select distinct AddressID from AdventureWorks2019.Person.Address)as a where a.AddressID=" + jTextField8.getText();
        try ( Connection conexion = DriverManager.getConnection(sqlserver.conexion1URL);  Statement s = conexion.createStatement();) {
            rs = s.executeQuery(query);
            while (rs.next()) {
                JOptionPane.showMessageDialog(null, "El dato " + jTextField8.getText() + " es válido");
                soh.setBillToAdressID(Integer.parseInt(jTextField8.getText()));
                soh.setShipToAdressID(Integer.parseInt(jTextField8.getText()));
                jLabel20.setText("" + soh.getShipToAdressID());
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "" + e);
        }
    }

    public void validar5() {
        String query = "select * from (select distinct ShipMethodID from AdventureWorks2019.Purchasing.ShipMethod)as a where a.ShipMethodID=" + jTextField10.getText();
        try ( Connection conexion = DriverManager.getConnection(sqlserver.conexion1URL);  Statement s = conexion.createStatement();) {
            rs = s.executeQuery(query);
            while (rs.next()) {
                JOptionPane.showMessageDialog(null, "El dato " + jTextField10.getText() + " es válido");
                soh.setShipMethodID(Integer.parseInt(jTextField10.getText()));
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "" + e);
        }
    }

    public void validar6() {
        String query = "select * from (select distinct CreditCardID from AdventureWorks2019.Sales.CreditCard)as a where a.CreditCardID=" + jTextField11.getText();
        try ( Connection conexion = DriverManager.getConnection(sqlserver.conexion2URL);  Statement s = conexion.createStatement();) {
            rs = s.executeQuery(query);
            while (rs.next()) {
                JOptionPane.showMessageDialog(null, "El dato " + jTextField11.getText() + " es válido");
                soh.setCreditCardID(Integer.parseInt(jTextField11.getText()));
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "" + e);
        }
    }

    public void validar7() {
        String query = "select * from (select distinct CurrencyRateID from AdventureWorks2019.Sales.CurrencyRate)as a where a.CurrencyRateID=" + jTextField9.getText();
        try ( Connection conexion = DriverManager.getConnection(sqlserver.conexion2URL);  Statement s = conexion.createStatement();) {
            rs = s.executeQuery(query);
            while (rs.next()) {
                JOptionPane.showMessageDialog(null, "El dato " + jTextField9.getText() + " es válido");
                soh.setCurrencyRateID(Integer.parseInt(jTextField9.getText()));
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "" + e);
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPasswordField1 = new javax.swing.JPasswordField();
        jButton1 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jTextField2 = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        jTextField3 = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        jTextField4 = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        jComboBox1 = new javax.swing.JComboBox<>();
        jLabel9 = new javax.swing.JLabel();
        jComboBox2 = new javax.swing.JComboBox<>();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jTextField5 = new javax.swing.JTextField();
        jTextField6 = new javax.swing.JTextField();
        jLabel15 = new javax.swing.JLabel();
        jTextField7 = new javax.swing.JTextField();
        jButton4 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        jLabel16 = new javax.swing.JLabel();
        jTextField8 = new javax.swing.JTextField();
        jButton7 = new javax.swing.JButton();
        jLabel17 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        jTextField10 = new javax.swing.JTextField();
        jButton9 = new javax.swing.JButton();
        jLabel19 = new javax.swing.JLabel();
        jTextField11 = new javax.swing.JTextField();
        jButton10 = new javax.swing.JButton();
        jTextField12 = new javax.swing.JTextField();
        jLabel20 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        jTextField9 = new javax.swing.JTextField();
        jButton3 = new javax.swing.JButton();
        jButton8 = new javax.swing.JButton();
        jLabel24 = new javax.swing.JLabel();
        jLabel25 = new javax.swing.JLabel();
        jButton11 = new javax.swing.JButton();
        jLabel26 = new javax.swing.JLabel();
        jLabel27 = new javax.swing.JLabel();
        jLabel28 = new javax.swing.JLabel();
        jTextField13 = new javax.swing.JTextField();
        jLabel29 = new javax.swing.JLabel();

        jPasswordField1.setText("jPasswordField1");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jButton1.setText("Atras");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jLabel1.setText("Sales Order Header Create");

        jLabel2.setText("Sales Order ID Asignado:");

        jButton2.setText("Crear");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jLabel4.setText("Revision Number: ");

        jLabel5.setText("Order Date:");

        jTextField2.setText("aaaa/mm/dd");

        jLabel6.setText("Due Date:");

        jTextField3.setText("aaaa/mm/dd");

        jLabel7.setText("Ship Date:");

        jTextField4.setText("aaaa/mm/dd");

        jLabel8.setText("Status:");

        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "In process", "Approved", "Backordered", "Rejected", "Shipped", "Cancelled" }));

        jLabel9.setText("Order Online Flag:");

        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Placed by Sales Person", "Placed Online by Customer" }));

        jLabel10.setText("Purchase Order Number:");

        jLabel12.setText("Account Number(15)");

        jLabel13.setText("CustomerID:");

        jLabel14.setText("SalesPersonID:");

        jLabel15.setText("TerritoryID:");

        jButton4.setText("Validar.");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        jButton5.setText("Validar.");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });

        jButton6.setText("Validar");
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });

        jLabel16.setText("BillToAdressID:");

        jButton7.setText("Validar.");
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });

        jLabel17.setText("ShipToAdressID:");

        jLabel18.setText("ShipMethodID:");

        jButton9.setText("Validar.");
        jButton9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton9ActionPerformed(evt);
            }
        });

        jLabel19.setText("CreditCardID:");

        jButton10.setText("Validar.");
        jButton10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton10ActionPerformed(evt);
            }
        });

        jTextField12.setText("nn-nnnn-nnnnnn");

        jLabel21.setText("Credit Card Approval Code:");

        jLabel23.setText("CurrencyRateID:");

        jButton3.setText("Validar.");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jButton8.setText("ObtenerID");
        jButton8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton8ActionPerformed(evt);
            }
        });

        jLabel24.setText("SubTotal:");

        jButton11.setText("Obtener.");
        jButton11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton11ActionPerformed(evt);
            }
        });

        jLabel26.setText("TaxAmt:");

        jLabel29.setText("Comentario:");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel15)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jTextField7, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(jButton6)
                                .addGap(53, 53, 53)
                                .addComponent(jLabel16)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jTextField8, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jButton7)
                                .addGap(33, 33, 33)
                                .addComponent(jLabel17)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jLabel20, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel18)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jTextField10, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(18, 18, 18)
                                        .addComponent(jButton9)
                                        .addGap(18, 18, 18)
                                        .addComponent(jLabel19)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jTextField11, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jButton10))
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(302, 302, 302)
                                        .addComponent(jLabel24)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jLabel25, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(46, 46, 46)
                                        .addComponent(jLabel26, javax.swing.GroupLayout.PREFERRED_SIZE, 68, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jLabel27)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel21)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jLabel22, javax.swing.GroupLayout.PREFERRED_SIZE, 147, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jButton1)
                            .addComponent(jLabel23)
                            .addComponent(jLabel29))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jTextField9, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jButton3)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel28, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addGap(18, 18, Short.MAX_VALUE)
                                .addComponent(jTextField13, javax.swing.GroupLayout.PREFERRED_SIZE, 659, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel8)
                                .addGap(18, 18, 18)
                                .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(43, 43, 43)
                                .addComponent(jLabel9)
                                .addGap(18, 18, 18)
                                .addComponent(jComboBox2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel12)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jTextField12, javax.swing.GroupLayout.PREFERRED_SIZE, 171, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel10)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(38, 38, 38)
                                .addComponent(jLabel13)
                                .addGap(18, 18, 18)
                                .addComponent(jTextField5, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(jButton4)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jTextField6, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jButton5)))
                        .addGap(26, 26, 26))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel2)
                                .addGap(12, 12, 12)
                                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jButton8))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel4)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 62, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(jLabel5)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(42, 42, 42)
                                .addComponent(jLabel6)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jTextField3, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(33, 33, 33)
                                .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 59, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(jTextField4, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addContainerGap())))
            .addGroup(layout.createSequentialGroup()
                .addGap(390, 390, 390)
                .addComponent(jButton2)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jButton11)
                        .addGap(412, 412, 412))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addGap(353, 353, 353))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addGap(16, 16, 16)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton8)
                    .addComponent(jLabel2)
                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(46, 46, 46)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel4)
                            .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel5)
                            .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel6)
                            .addComponent(jTextField3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel7)
                            .addComponent(jTextField4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(29, 29, 29)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel8)
                            .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel9)
                            .addComponent(jComboBox2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel12)
                            .addComponent(jTextField12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(31, 31, 31)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel10)
                            .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel13)
                        .addComponent(jTextField5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jButton4)
                        .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jTextField6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jButton5)))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel15)
                    .addComponent(jTextField7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton6)
                    .addComponent(jLabel16)
                    .addComponent(jTextField8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton7)
                    .addComponent(jLabel17)
                    .addComponent(jLabel20, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel18)
                    .addComponent(jTextField10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton9)
                    .addComponent(jLabel19)
                    .addComponent(jTextField11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton10)
                    .addComponent(jLabel21)
                    .addComponent(jLabel22, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel23)
                        .addComponent(jTextField9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jButton3)
                        .addComponent(jLabel24)
                        .addComponent(jLabel25, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jLabel27)
                    .addComponent(jLabel26, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel28, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(18, 18, 18)
                .addComponent(jButton11)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 27, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextField13, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel29))
                .addGap(22, 22, 22)
                .addComponent(jButton2)
                .addGap(3, 3, 3)
                .addComponent(jButton1)
                .addGap(14, 14, 14))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        this.dispose();
        dao.setVisible(true);
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
        //generaID();
        insert();
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        // TODO add your handling code here:
        validar1();
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        // TODO add your handling code here:
        validar2();
    }//GEN-LAST:event_jButton5ActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
        // TODO add your handling code here:
        validar3();
    }//GEN-LAST:event_jButton6ActionPerformed

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
        // TODO add your handling code here:
        validar4();
    }//GEN-LAST:event_jButton7ActionPerformed

    private void jButton9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton9ActionPerformed
        // TODO add your handling code here:
        validar5();
    }//GEN-LAST:event_jButton9ActionPerformed

    private void jButton10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton10ActionPerformed
        // TODO add your handling code here:
        validar6();
    }//GEN-LAST:event_jButton10ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // TODO add your handling code here:
        validar7();
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton8ActionPerformed
        // TODO add your handling code here:
        generaID();
        sodc.setVisible(true);
    }//GEN-LAST:event_jButton8ActionPerformed

    private void jButton11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton11ActionPerformed
        // TODO add your handling code here:
        calculos();
    }//GEN-LAST:event_jButton11ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(SOH_Create.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(SOH_Create.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(SOH_Create.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(SOH_Create.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new SOH_Create().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton10;
    private javax.swing.JButton jButton11;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JButton jButton8;
    private javax.swing.JButton jButton9;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JComboBox<String> jComboBox2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPasswordField jPasswordField1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField10;
    private javax.swing.JTextField jTextField11;
    private javax.swing.JTextField jTextField12;
    private javax.swing.JTextField jTextField13;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField3;
    private javax.swing.JTextField jTextField4;
    private javax.swing.JTextField jTextField5;
    private javax.swing.JTextField jTextField6;
    private javax.swing.JTextField jTextField7;
    private javax.swing.JTextField jTextField8;
    private javax.swing.JTextField jTextField9;
    // End of variables declaration//GEN-END:variables
}
