/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Purchasing;

import java.util.Date;

/**
 *
 * @author luisp
 */
public class Vendor {
private int BusinessEntity;
private String AccountNumber;
private String Name;
private int CreditRating;
private boolean PreferredVendorStatus;
private boolean ActiveFlag;
private String PurchasingWebServiceURL;
private Date ModifiedDate;

    public int getBusinessEntity() {
        return BusinessEntity;
    }

    public void setBusinessEntity(int BusinessEntity) {
        this.BusinessEntity = BusinessEntity;
    }

    public String getAccountNumber() {
        return AccountNumber;
    }

    public void setAccountNumber(String AccountNumber) {
        this.AccountNumber = AccountNumber;
    }

    public String getName() {
        return Name;
    }

    public void setName(String Name) {
        this.Name = Name;
    }

    public int getCreditRating() {
        return CreditRating;
    }

    public void setCreditRating(int CreditRating) {
        this.CreditRating = CreditRating;
    }

    public boolean isPreferredVendorStatus() {
        return PreferredVendorStatus;
    }

    public void setPreferredVendorStatus(boolean PreferredVendorStatus) {
        this.PreferredVendorStatus = PreferredVendorStatus;
    }

    public boolean isActiveFlag() {
        return ActiveFlag;
    }

    public void setActiveFlag(boolean ActiveFlag) {
        this.ActiveFlag = ActiveFlag;
    }

    public String getPurchasingWebServiceURL() {
        return PurchasingWebServiceURL;
    }

    public void setPurchasingWebServiceURL(String PurchasingWebServiceURL) {
        this.PurchasingWebServiceURL = PurchasingWebServiceURL;
    }

    public Date getModifiedDate() {
        return ModifiedDate;
    }

    public void setModifiedDate(Date ModifiedDate) {
        this.ModifiedDate = ModifiedDate;
    }
}
