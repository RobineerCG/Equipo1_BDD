/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Purchasing;

import java.math.BigDecimal;
import java.util.Date;

/**
 *
 * @author luisp
 */
public class PurchaseOrderHeader {
 private int PurchaseOrderID;
 private int RevisionNumber;
 private int Status;
 private int EmployeeID;
 private int Vendor;
 private int ShipMethodID;
 private Date OrderDate;
 private Date ShipDate;
 private BigDecimal SubTotal;
 private BigDecimal TaxAmt;
 private BigDecimal Freight;
 private BigDecimal TotalDue;
 private Date ModifiedDate;

    public int getPurchaseOrderID() {
        return PurchaseOrderID;
    }

    public void setPurchaseOrderID(int PurchaseOrderID) {
        this.PurchaseOrderID = PurchaseOrderID;
    }

    public int getRevisionNumber() {
        return RevisionNumber;
    }

    public void setRevisionNumber(int RevisionNumber) {
        this.RevisionNumber = RevisionNumber;
    }

    public int getStatus() {
        return Status;
    }

    public void setStatus(int Status) {
        this.Status = Status;
    }

    public int getEmployeeID() {
        return EmployeeID;
    }

    public void setEmployeeID(int EmployeeID) {
        this.EmployeeID = EmployeeID;
    }

    public int getVendor() {
        return Vendor;
    }

    public void setVendor(int Vendor) {
        this.Vendor = Vendor;
    }

    public int getShipMethodID() {
        return ShipMethodID;
    }

    public void setShipMethodID(int ShipMethodID) {
        this.ShipMethodID = ShipMethodID;
    }

    public Date getOrderDate() {
        return OrderDate;
    }

    public void setOrderDate(Date OrderDate) {
        this.OrderDate = OrderDate;
    }

    public Date getShipDate() {
        return ShipDate;
    }

    public void setShipDate(Date ShipDate) {
        this.ShipDate = ShipDate;
    }

    public BigDecimal getSubTotal() {
        return SubTotal;
    }

    public void setSubTotal(BigDecimal SubTotal) {
        this.SubTotal = SubTotal;
    }

    public BigDecimal getTaxAmt() {
        return TaxAmt;
    }

    public void setTaxAmt(BigDecimal TaxAmt) {
        this.TaxAmt = TaxAmt;
    }

    public BigDecimal getFreight() {
        return Freight;
    }

    public void setFreight(BigDecimal Freight) {
        this.Freight = Freight;
    }

    public BigDecimal getTotalDue() {
        return TotalDue;
    }

    public void setTotalDue(BigDecimal TotalDue) {
        this.TotalDue = TotalDue;
    }

    public Date getModifiedDate() {
        return ModifiedDate;
    }

    public void setModifiedDate(Date ModifiedDate) {
        this.ModifiedDate = ModifiedDate;
    }
 
 
}
