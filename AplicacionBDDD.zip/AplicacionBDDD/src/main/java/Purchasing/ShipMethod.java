/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Purchasing;

import java.math.BigDecimal;
import java.util.Date;

/**
 *
 * @author luisp
 */
public class ShipMethod {
 private int ShipMethodID;
 private String Name;
 private BigDecimal ShipBase;
 private BigDecimal ShipRate;
 private String rowguid;
 private Date ModifiedDate;

    public int getShipMethodID() {
        return ShipMethodID;
    }

    public void setShipMethodID(int ShipMethodID) {
        this.ShipMethodID = ShipMethodID;
    }

    public String getName() {
        return Name;
    }

    public void setName(String Name) {
        this.Name = Name;
    }

    public BigDecimal getShipBase() {
        return ShipBase;
    }

    public void setShipBase(BigDecimal ShipBase) {
        this.ShipBase = ShipBase;
    }

    public BigDecimal getShipRate() {
        return ShipRate;
    }

    public void setShipRate(BigDecimal ShipRate) {
        this.ShipRate = ShipRate;
    }

    public String getRowguid() {
        return rowguid;
    }

    public void setRowguid(String rowguid) {
        this.rowguid = rowguid;
    }

    public Date getModifiedDate() {
        return ModifiedDate;
    }

    public void setModifiedDate(Date ModifiedDate) {
        this.ModifiedDate = ModifiedDate;
    }
 
 
}
