/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Purchasing;

import java.math.BigDecimal;
import java.util.Date;

/**
 *
 * @author luisp
 */
public class ProductVendor {
private int ProductID;
private int BusinessEntity;
private int AverageLeadTime;
private BigDecimal StandardPrice;
private BigDecimal LastReceiptCost;
private Date LastReceiptDate;
private int MinOrderQty;
private int MaxOrderQty;
private int OnOrderQty;
private String UnitMeasureCode;
private Date ModifiedDate;

    public int getProductID() {
        return ProductID;
    }

    public void setProductID(int ProductID) {
        this.ProductID = ProductID;
    }

    public int getBusinessEntity() {
        return BusinessEntity;
    }

    public void setBusinessEntity(int BusinessEntity) {
        this.BusinessEntity = BusinessEntity;
    }

    public int getAverageLeadTime() {
        return AverageLeadTime;
    }

    public void setAverageLeadTime(int AverageLeadTime) {
        this.AverageLeadTime = AverageLeadTime;
    }

    public BigDecimal getStandardPrice() {
        return StandardPrice;
    }

    public void setStandardPrice(BigDecimal StandardPrice) {
        this.StandardPrice = StandardPrice;
    }

    public BigDecimal getLastReceiptCost() {
        return LastReceiptCost;
    }

    public void setLastReceiptCost(BigDecimal LastReceiptCost) {
        this.LastReceiptCost = LastReceiptCost;
    }

    public Date getLastReceiptDate() {
        return LastReceiptDate;
    }

    public void setLastReceiptDate(Date LastReceiptDate) {
        this.LastReceiptDate = LastReceiptDate;
    }

    public int getMinOrderQty() {
        return MinOrderQty;
    }

    public void setMinOrderQty(int MinOrderQty) {
        this.MinOrderQty = MinOrderQty;
    }

    public int getMaxOrderQty() {
        return MaxOrderQty;
    }

    public void setMaxOrderQty(int MaxOrderQty) {
        this.MaxOrderQty = MaxOrderQty;
    }

    public int getOnOrderQty() {
        return OnOrderQty;
    }

    public void setOnOrderQty(int OnOrderQty) {
        this.OnOrderQty = OnOrderQty;
    }

    public String getUnitMeasureCode() {
        return UnitMeasureCode;
    }

    public void setUnitMeasureCode(String UnitMeasureCode) {
        this.UnitMeasureCode = UnitMeasureCode;
    }

    public Date getModifiedDate() {
        return ModifiedDate;
    }

    public void setModifiedDate(Date ModifiedDate) {
        this.ModifiedDate = ModifiedDate;
    }


}
