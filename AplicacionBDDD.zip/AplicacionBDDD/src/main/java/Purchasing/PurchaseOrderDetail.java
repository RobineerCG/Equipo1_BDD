/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Purchasing;

import java.math.BigDecimal;
import java.util.Date;

/**
 *
 * @author luisp
 */
public class PurchaseOrderDetail {
 private int PurchaseOrderId;
 private int PurchaseOrderDetailID;
 private Date DueDate;
 private int OrderQty;
 private int ProductID;
 private BigDecimal UnitPrice;
 private BigDecimal LineTotal;
 private double ReceivedQty;
 private double RejectedQty;
 private double StockedQty;
 private Date ModifiedDate;

    public int getPurchaseOrderId() {
        return PurchaseOrderId;
    }

    public void setPurchaseOrderId(int PurchaseOrderId) {
        this.PurchaseOrderId = PurchaseOrderId;
    }

    public int getPurchaseOrderDetailID() {
        return PurchaseOrderDetailID;
    }

    public void setPurchaseOrderDetailID(int PurchaseOrderDetailID) {
        this.PurchaseOrderDetailID = PurchaseOrderDetailID;
    }

    public Date getDueDate() {
        return DueDate;
    }

    public void setDueDate(Date DueDate) {
        this.DueDate = DueDate;
    }

    public int getOrderQty() {
        return OrderQty;
    }

    public void setOrderQty(int OrderQty) {
        this.OrderQty = OrderQty;
    }

    public int getProductID() {
        return ProductID;
    }

    public void setProductID(int ProductID) {
        this.ProductID = ProductID;
    }

    public BigDecimal getUnitPrice() {
        return UnitPrice;
    }

    public void setUnitPrice(BigDecimal UnitPrice) {
        this.UnitPrice = UnitPrice;
    }

    public BigDecimal getLineTotal() {
        return LineTotal;
    }

    public void setLineTotal(BigDecimal LineTotal) {
        this.LineTotal = LineTotal;
    }

    public double getReceivedQty() {
        return ReceivedQty;
    }

    public void setReceivedQty(double ReceivedQty) {
        this.ReceivedQty = ReceivedQty;
    }

    public double getRejectedQty() {
        return RejectedQty;
    }

    public void setRejectedQty(double RejectedQty) {
        this.RejectedQty = RejectedQty;
    }

    public double getStockedQty() {
        return StockedQty;
    }

    public void setStockedQty(double StockedQty) {
        this.StockedQty = StockedQty;
    }

    public Date getModifiedDate() {
        return ModifiedDate;
    }

    public void setModifiedDate(Date ModifiedDate) {
        this.ModifiedDate = ModifiedDate;
    }
 
 
 
}
