/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Person;

import java.util.Date;

/**
 *
 * @author luisp
 */
public class StateProvince {
 private int StateProvinceID;
 private String StateProvinceCode;
 private String CountryRegionCode;
 private boolean IsOnlyStateProvinceFlag;
 private String Name;
 private int TerritoryID;
 private String rowguid;
 private Date ModifiedDate;

    public int getStateProvinceID() {
        return StateProvinceID;
    }

    public void setStateProvinceID(int StateProvinceID) {
        this.StateProvinceID = StateProvinceID;
    }

    public String getStateProvinceCode() {
        return StateProvinceCode;
    }

    public void setStateProvinceCode(String StateProvinceCode) {
        this.StateProvinceCode = StateProvinceCode;
    }

    public String getCountryRegionCode() {
        return CountryRegionCode;
    }

    public void setCountryRegionCode(String CountryRegionCode) {
        this.CountryRegionCode = CountryRegionCode;
    }

    public boolean isIsOnlyStateProvinceFlag() {
        return IsOnlyStateProvinceFlag;
    }

    public void setIsOnlyStateProvinceFlag(boolean IsOnlyStateProvinceFlag) {
        this.IsOnlyStateProvinceFlag = IsOnlyStateProvinceFlag;
    }

    public String getName() {
        return Name;
    }

    public void setName(String Name) {
        this.Name = Name;
    }

    public int getTerritoryID() {
        return TerritoryID;
    }

    public void setTerritoryID(int TerritoryID) {
        this.TerritoryID = TerritoryID;
    }

    public String getRowguid() {
        return rowguid;
    }

    public void setRowguid(String rowguid) {
        this.rowguid = rowguid;
    }

    public Date getModifiedDate() {
        return ModifiedDate;
    }

    public void setModifiedDate(Date ModifiedDate) {
        this.ModifiedDate = ModifiedDate;
    }
 
 
}
