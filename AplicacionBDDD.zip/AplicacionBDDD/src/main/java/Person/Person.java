/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Person;

import java.util.Date;

/**
 *
 * @author luisp
 */
public class Person {

    private int BusinessEntityID;
    private String PersonType;
    private boolean NameStyle;
    private String Title;
    private String FirstName;
    private String MiddleName;
    private String LastName;
    private String Suffix;
    private int EmailPromotion;
    private String AdditionalContactInfo;
    private String Demographics;
    private String rowguid;
    private Date ModifiedDate;

    public int getBusinessEntityID() {
        return BusinessEntityID;
    }

    public void setBusinessEntityID(int BusinessEntityID) {
        this.BusinessEntityID = BusinessEntityID;
    }

    public String getPersonType() {
        return PersonType;
    }

    public void setPersonType(String PersonType) {
        this.PersonType = PersonType;
    }

    public boolean isNameStyle() {
        return NameStyle;
    }

    public void setNameStyle(boolean NameStyle) {
        this.NameStyle = NameStyle;
    }

    public String getTitle() {
        return Title;
    }

    public void setTitle(String Title) {
        this.Title = Title;
    }

    public String getFirstName() {
        return FirstName;
    }

    public void setFirstName(String FirstName) {
        this.FirstName = FirstName;
    }

    public String getMiddleName() {
        return MiddleName;
    }

    public void setMiddleName(String MiddleName) {
        this.MiddleName = MiddleName;
    }

    public String getLastName() {
        return LastName;
    }

    public void setLastName(String LastName) {
        this.LastName = LastName;
    }

    public String getSuffix() {
        return Suffix;
    }

    public void setSuffix(String Suffix) {
        this.Suffix = Suffix;
    }

    public int getEmailPromotion() {
        return EmailPromotion;
    }

    public void setEmailPromotion(int EmailPromotion) {
        this.EmailPromotion = EmailPromotion;
    }

    public String getAdditionalContactInfo() {
        return AdditionalContactInfo;
    }

    public void setAdditionalContactInfo(String AdditionalContactInfo) {
        this.AdditionalContactInfo = AdditionalContactInfo;
    }

    public String getDemographics() {
        return Demographics;
    }

    public void setDemographics(String Demographics) {
        this.Demographics = Demographics;
    }

    public String getRowguid() {
        return rowguid;
    }

    public void setRowguid(String rowguid) {
        this.rowguid = rowguid;
    }

    public Date getModifiedDate() {
        return ModifiedDate;
    }

    public void setModifiedDate(Date ModifiedDate) {
        this.ModifiedDate = ModifiedDate;
    }
    
    
    
}
