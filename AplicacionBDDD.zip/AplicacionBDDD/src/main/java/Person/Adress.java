/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Person;

import java.util.Date;

/**
 *
 * @author luisp
 */
public class Adress {
 private int AdressID;
 private String AdressLine1;
 private String AdressLine2;
 private String City;
 private int StateProvinceID;
 private String PostalCode;
 private String SpatialLocation;
 private String rowguid;
 private Date ModifiedDate;

    public int getAdressID() {
        return AdressID;
    }

    public void setAdressID(int AdressID) {
        this.AdressID = AdressID;
    }

    public String getAdressLine1() {
        return AdressLine1;
    }

    public void setAdressLine1(String AdressLine1) {
        this.AdressLine1 = AdressLine1;
    }

    public String getAdressLine2() {
        return AdressLine2;
    }

    public void setAdressLine2(String AdressLine2) {
        this.AdressLine2 = AdressLine2;
    }

    public String getCity() {
        return City;
    }

    public void setCity(String City) {
        this.City = City;
    }

    public int getStateProvinceID() {
        return StateProvinceID;
    }

    public void setStateProvinceID(int StateProvinceID) {
        this.StateProvinceID = StateProvinceID;
    }

    public String getPostalCode() {
        return PostalCode;
    }

    public void setPostalCode(String PostalCode) {
        this.PostalCode = PostalCode;
    }

    public String getSpatialLocation() {
        return SpatialLocation;
    }

    public void setSpatialLocation(String SpatialLocation) {
        this.SpatialLocation = SpatialLocation;
    }

    public String getRowguid() {
        return rowguid;
    }

    public void setRowguid(String rowguid) {
        this.rowguid = rowguid;
    }

    public Date getModifiedDate() {
        return ModifiedDate;
    }

    public void setModifiedDate(Date ModifiedDate) {
        this.ModifiedDate = ModifiedDate;
    }
 
 
}
