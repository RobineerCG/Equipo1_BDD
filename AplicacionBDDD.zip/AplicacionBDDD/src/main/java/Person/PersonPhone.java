/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Person;

import java.util.Date;

/**
 *
 * @author luisp
 */
public class PersonPhone {
 private int BusinessEntityID;
 private String PhoneNumber;
 private int PhoneNumberTypeID;
 private Date ModifiedDate;

    public int getBusinessEntityID() {
        return BusinessEntityID;
    }

    public void setBusinessEntityID(int BusinessEntityID) {
        this.BusinessEntityID = BusinessEntityID;
    }

    public String getPhoneNumber() {
        return PhoneNumber;
    }

    public void setPhoneNumber(String PhoneNumber) {
        this.PhoneNumber = PhoneNumber;
    }

    public int getPhoneNumberTypeID() {
        return PhoneNumberTypeID;
    }

    public void setPhoneNumberTypeID(int PhoneNumberTypeID) {
        this.PhoneNumberTypeID = PhoneNumberTypeID;
    }

    public Date getModifiedDate() {
        return ModifiedDate;
    }

    public void setModifiedDate(Date ModifiedDate) {
        this.ModifiedDate = ModifiedDate;
    }
 
 
}
