/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Person;

import java.util.Date;

/**
 *
 * @author luisp
 */
public class EmailAdress {
private int BusinessEntityID;
private int EmailAdressID;
private String EmailAdress;
private String rowguid;
private Date ModifiedDate;

    public int getBusinessEntityID() {
        return BusinessEntityID;
    }

    public void setBusinessEntityID(int BusinessEntityID) {
        this.BusinessEntityID = BusinessEntityID;
    }

    public int getEmailAdressID() {
        return EmailAdressID;
    }

    public void setEmailAdressID(int EmailAdressID) {
        this.EmailAdressID = EmailAdressID;
    }

    public String getEmailAdress() {
        return EmailAdress;
    }

    public void setEmailAdress(String EmailAdress) {
        this.EmailAdress = EmailAdress;
    }

    public String getRowguid() {
        return rowguid;
    }

    public void setRowguid(String rowguid) {
        this.rowguid = rowguid;
    }

    public Date getModifiedDate() {
        return ModifiedDate;
    }

    public void setModifiedDate(Date ModifiedDate) {
        this.ModifiedDate = ModifiedDate;
    }


}
