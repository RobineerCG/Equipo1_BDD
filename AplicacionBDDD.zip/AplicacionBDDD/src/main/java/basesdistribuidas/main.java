
package basesdistribuidas;

import DataSource.sqlserver;
import DataSource.mysql;
import GUI.Bienvenida;
import Sales.*;
import java.sql.SQLException;
//import conexion.mysqlconection;


public class main {
    public static void main(String[] args) throws SQLException {
        /*
        System.out.println("Probando con SQL");
        sqlserver con1= new sqlserver();
        System.out.println("Probando con MySQL");
        mysql con2 = new mysql();
        mysql.connect();
        SalesOrderHeader sales = new SalesOrderHeader();
        sales.select();
        */
        System.out.println("Mostrando Interfaz....");
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Bienvenida().setVisible(true);
            }
        });
    }
}
