/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package HumanResources;

import java.util.Date;
import java.util.Timer;

/**
 *
 * @author luisp
 */
public class Shift {
    private int ShiftID;
    private String Name;
    private Timer StartTime;
    private Timer EndTime;
    private Date ModifiedDate;

    public int getShiftID() {
        return ShiftID;
    }

    public void setShiftID(int ShiftID) {
        this.ShiftID = ShiftID;
    }

    public String getName() {
        return Name;
    }

    public void setName(String Name) {
        this.Name = Name;
    }

    public Timer getStartTime() {
        return StartTime;
    }

    public void setStartTime(Timer StartTime) {
        this.StartTime = StartTime;
    }

    public Timer getEndTime() {
        return EndTime;
    }

    public void setEndTime(Timer EndTime) {
        this.EndTime = EndTime;
    }

    public Date getModifiedDate() {
        return ModifiedDate;
    }

    public void setModifiedDate(Date ModifiedDate) {
        this.ModifiedDate = ModifiedDate;
    }
    
    
}
