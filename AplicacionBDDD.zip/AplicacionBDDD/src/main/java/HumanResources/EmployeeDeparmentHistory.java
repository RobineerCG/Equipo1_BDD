/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package HumanResources;

import java.util.Date;

/**
 *
 * @author luisp
 */
public class EmployeeDeparmentHistory {
  private int BusinessEntity;
  private int DepartmentID; 
  private int ShiftID;
  private Date StartDate;
  private Date EndDate;
  private Date ModifiedDate;

    public int getBusinessEntity() {
        return BusinessEntity;
    }

    public void setBusinessEntity(int BusinessEntity) {
        this.BusinessEntity = BusinessEntity;
    }

    public int getDepartmentID() {
        return DepartmentID;
    }

    public void setDepartmentID(int DepartmentID) {
        this.DepartmentID = DepartmentID;
    }

    public int getShiftID() {
        return ShiftID;
    }

    public void setShiftID(int ShiftID) {
        this.ShiftID = ShiftID;
    }

    public Date getStartDate() {
        return StartDate;
    }

    public void setStartDate(Date StartDate) {
        this.StartDate = StartDate;
    }

    public Date getEndDate() {
        return EndDate;
    }

    public void setEndDate(Date EndDate) {
        this.EndDate = EndDate;
    }

    public Date getModifiedDate() {
        return ModifiedDate;
    }

    public void setModifiedDate(Date ModifiedDate) {
        this.ModifiedDate = ModifiedDate;
    }
  
  
}
