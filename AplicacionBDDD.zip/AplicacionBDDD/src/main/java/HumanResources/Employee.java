/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package HumanResources;

import java.util.Date;

/**
 *
 * @author luisp
 */
public class Employee {
   private int BusinessEntity;
   private String NationalIDNumber;
   private String LoginID;
   private String OrganitationNode;
   private int OrganitationLevel;
   private String JobTitle;
   private Date BirthDate;
   private char MaritalStatus;
   private char Gender;
   private Date HireDate;
   private boolean SalariedFlag;
   private int VacationHours;
   private int SickLeaveHours;
   private boolean CurrentFlag;
   private String rowguid;
   private Date ModifiedDate;

    public int getBusinessEntity() {
        return BusinessEntity;
    }

    public void setBusinessEntity(int BusinessEntity) {
        this.BusinessEntity = BusinessEntity;
    }

    public String getNationalIDNumber() {
        return NationalIDNumber;
    }

    public void setNationalIDNumber(String NationalIDNumber) {
        this.NationalIDNumber = NationalIDNumber;
    }

    public String getLoginID() {
        return LoginID;
    }

    public void setLoginID(String LoginID) {
        this.LoginID = LoginID;
    }

    public String getOrganitationNode() {
        return OrganitationNode;
    }

    public void setOrganitationNode(String OrganitationNode) {
        this.OrganitationNode = OrganitationNode;
    }

    public int getOrganitationLevel() {
        return OrganitationLevel;
    }

    public void setOrganitationLevel(int OrganitationLevel) {
        this.OrganitationLevel = OrganitationLevel;
    }

    public String getJobTitle() {
        return JobTitle;
    }

    public void setJobTitle(String JobTitle) {
        this.JobTitle = JobTitle;
    }

    public Date getBirthDate() {
        return BirthDate;
    }

    public void setBirthDate(Date BirthDate) {
        this.BirthDate = BirthDate;
    }

    public char getMaritalStatus() {
        return MaritalStatus;
    }

    public void setMaritalStatus(char MaritalStatus) {
        this.MaritalStatus = MaritalStatus;
    }

    public char getGender() {
        return Gender;
    }

    public void setGender(char Gender) {
        this.Gender = Gender;
    }

    public Date getHireDate() {
        return HireDate;
    }

    public void setHireDate(Date HireDate) {
        this.HireDate = HireDate;
    }

    public boolean isSalariedFlag() {
        return SalariedFlag;
    }

    public void setSalariedFlag(boolean SalariedFlag) {
        this.SalariedFlag = SalariedFlag;
    }

    public int getVacationHours() {
        return VacationHours;
    }

    public void setVacationHours(int VacationHours) {
        this.VacationHours = VacationHours;
    }

    public int getSickLeaveHours() {
        return SickLeaveHours;
    }

    public void setSickLeaveHours(int SickLeaveHours) {
        this.SickLeaveHours = SickLeaveHours;
    }

    public boolean isCurrentFlag() {
        return CurrentFlag;
    }

    public void setCurrentFlag(boolean CurrentFlag) {
        this.CurrentFlag = CurrentFlag;
    }

    public String getRowguid() {
        return rowguid;
    }

    public void setRowguid(String rowguid) {
        this.rowguid = rowguid;
    }

    public Date getModifiedDate() {
        return ModifiedDate;
    }

    public void setModifiedDate(Date ModifiedDate) {
        this.ModifiedDate = ModifiedDate;
    }
   
   
}
