/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package HumanResources;

import java.math.BigDecimal;
import java.util.Date;

/**
 *
 * @author luisp
 */
public class EmployeePayHistory {
  private int BusinessEntityID;
  private  Date RateChangeDate;
  private BigDecimal Rate;
  private int PayFrecuency;
  private Date ModifiedDate;

    public int getBusinessEntityID() {
        return BusinessEntityID;
    }

    public void setBusinessEntityID(int BusinessEntityID) {
        this.BusinessEntityID = BusinessEntityID;
    }

    public Date getRateChangeDate() {
        return RateChangeDate;
    }

    public void setRateChangeDate(Date RateChangeDate) {
        this.RateChangeDate = RateChangeDate;
    }

    public BigDecimal getRate() {
        return Rate;
    }

    public void setRate(BigDecimal Rate) {
        this.Rate = Rate;
    }

    public int getPayFrecuency() {
        return PayFrecuency;
    }

    public void setPayFrecuency(int PayFrecuency) {
        this.PayFrecuency = PayFrecuency;
    }

    public Date getModifiedDate() {
        return ModifiedDate;
    }

    public void setModifiedDate(Date ModifiedDate) {
        this.ModifiedDate = ModifiedDate;
    }
  
  
}
