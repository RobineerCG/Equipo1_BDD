/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package HumanResources;

import java.util.Date;

/**
 *
 * @author luisp
 */
public class JobCandidate {
    private int JobCandidateID;
    private int BusinesEntityID;
    private String Resume;
    private Date ModifiedDate;

    public int getJobCandidateID() {
        return JobCandidateID;
    }

    public void setJobCandidateID(int JobCandidateID) {
        this.JobCandidateID = JobCandidateID;
    }

    public int getBusinesEntityID() {
        return BusinesEntityID;
    }

    public void setBusinesEntityID(int BusinesEntityID) {
        this.BusinesEntityID = BusinesEntityID;
    }

    public String getResume() {
        return Resume;
    }

    public void setResume(String Resume) {
        this.Resume = Resume;
    }

    public Date getModifiedDate() {
        return ModifiedDate;
    }

    public void setModifiedDate(Date ModifiedDate) {
        this.ModifiedDate = ModifiedDate;
    }
    
    
}
